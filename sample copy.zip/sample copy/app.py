from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# MySQL configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Vigneshwar@94",
    database="flask_app"
)

@app.route('/')
def index():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    cursor.close()
    return render_template('main.html', users=users)

@app.route('/add_user', methods=['POST'])
def add_user():
    username = request.form['username']
    email = request.form['email']
    cursor = db.cursor()
    cursor.execute("INSERT INTO users (username, email) VALUES (%s, %s)", (username, email))
    db.commit()
    cursor.close()
    return redirect(url_for('index'))

@app.route('/del_user', methods=['POST'])
def del_user():
    username = request.form['username']
    cursor = db.cursor()
    cursor.execute("DELETE FROM users WHERE username = (%s)", (username,))
    db.commit()
    cursor.close()
    return redirect(url_for('index'))

@app.route('/cust_login', methods=['POST'])
def cust_login():
    username =  request.form['username']
    cursor = db.cursor()
    query = "SELECT * FROM users WHERE username = %s AND password = %s"
    cursor.execute(query, (username, password))
    user = cursor.fetchone()
    if user:
        print("Login successful!")
    else:
        print("Login failed. Invalid username or password.")
    db.commit()
    cursor.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
